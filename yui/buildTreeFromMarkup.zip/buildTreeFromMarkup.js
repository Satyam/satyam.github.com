	YAHOO.widget.TreeView.prototype.buildTreeFromMarkup = function (id) {
		this.logger.log('Building tree from existing markup');
		var build = function (markup) {
			var el, child, branch = [], config = {}, label, yuiConfig;
			// Dom's getFirstChild and getNextSibling skip over text elements
			for (el = Dom.getFirstChild(markup); el; el = Dom.getNextSibling(el)) {
				switch (el.tagName.toUpperCase()) {
					case 'LI':
						config = {
							expanded: Dom.hasClass(el,'expanded'),
							title: el.title || el.alt || undefined
						};
						// I cannot skip over text elements here because I want them for labels
						child = el.firstChild;
						if (child.nodeType == 3) {
							// nodes with only whitespace, tabs and new lines don't count, they are probably just formatting.
							label = Lang.trim(child.nodeValue.replace(/[\n\t\r]*/g,''));
							if (label) {
								config.type = 'text';
								config.label = label;
							} else {
								child = Dom.getNextSibling(child);
							}
						}
						if (!label) {
							if (child.tagName.toUpperCase() == 'A') {
								config.type = 'text';
								config.label = child.innerHTML;
								config.href = child.href;
								config.target = child.target;
								config.title = child.title || child.alt || config.title;
							} else {
								config.type = 'html';
								var d = document.createElement('div');
								d.appendChild(child.cloneNode(true));
								config.html = d.innerHTML;
								config.hasIcon = true;
							}
						}
						// see if after the label it has a further list which will become children of this node.
						child = Dom.getNextSibling(child);
						switch (child && child.tagName.toUpperCase()) {
							case 'UL':
							case 'OL':
								config.children = build(child);
								break;
						}
						// if there are further elements or text, it will be ignored.
						
						if (YAHOO.lang.JSON) {
							yuiConfig = el.getAttribute('yuiConfig');
							if (yuiConfig) {
								yuiConfig = YAHOO.lang.JSON.parse(yuiConfig);
								config = YAHOO.lang.merge(config,yuiConfig);
							}
						}
						
						branch.push(config);
						break;
					case 'UL':
					case 'OL':
						this.logger.log('ULs or OLs can only contain LI elements, not other UL or OL.  This will not work in some browsers','error');
						config = {
							type: 'text',
							label: '',
							children: build(child)
						};
						branch.push(config);
						break;
				}
			}
			return branch;
		};

		var markup = Dom.getChildrenBy(Dom.get(id),function (el) { 
			var tag = el.tagName.toUpperCase();
			return  tag == 'UL' || tag == 'OL';
		});
		if (markup.length) {
			this.buildTreeFromObject(build(markup[0]));
		} else {
			this.logger.log('Markup contains no UL or OL elements','warn');
		}
	};
