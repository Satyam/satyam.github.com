<style type="text/css">
.whitebg {
	background-color:white;
}
</style>