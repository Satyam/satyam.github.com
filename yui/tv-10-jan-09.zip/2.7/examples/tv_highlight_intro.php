<p>In this simple example you can see how to do node selection in the
<a href="http://developer.yahoo.com/yui/treeview/">TreeView Control</a>.</p>


