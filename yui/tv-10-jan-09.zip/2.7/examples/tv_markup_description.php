<h2 class="first">Building trees from HTML markup or from previous definitions.</h2>

<p>In this brief example for the <a href="http://developer.yahoo.com/yui/treeview/">TreeView Control</a>, 
we begin with a <code>&lt;div&gt;</code> containing a set of nested unordered lists <code>&lt;ul&gt;</code>
providing the basic tree structure.</p>
<p>Each &lt;li&gt; element in the markup will produce a Node.  
List-items with plain text will produce regular TextNodes, 
those with the className "expanded" will override the default of showing nodes collapsed.
The list-item with a link will also produce a TextNode with its <code>href</code> and <code>target</code> properties set accordingly. 
The list-item containing a Date, being a string, would normally create a TextNode, 
but it has been overridden by the use of the <code>yuiConfig</code> attribute to make it a DateNode and editable.
The final node contains formatted text which will produce an HTMLNode;
the whole has to be enclosed in a single HTML element to let the parser know how far it reaches.</p>

<textarea name="code" class="HTML" cols="60" rows="1"><div id="markup">
	<ul>
		<li class="expanded">List 0
			<ul>
				<li class="expanded">List 0-0
					<ul>
						<li>item 0-0-0</li>
						<li><a target="_new" href="www.elsewhere.com" title="go elsewhere">elsewhere</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li>List 1
			<ul>
				<li>List 1-0
					<ul>
						<li yuiConfig='{"type":"DateNode","editable":true}'>02/01/2009</li>
						<li><span>item <strong>1-1-0</strong></span></li>
					</ul>
				</li>
			</ul>
		</li>
	</ul>
</div></textarea>

<p>We create a new TreeView and render it.  
The TreeView will read the existing HTML and build the nodes from it.
We also subscribe to the <code>dblClickEvent</code> to enable editing to prove the DateNode is really such and is editable.
</p>

<textarea name="code" class="JScript" cols="60" rows="1">tree1 = new YAHOO.widget.TreeView("markup");
tree1.render();

tree1.subscribe('dblClickEvent',tree1.onEventEditNode);</textarea>

<p>Once we have a tree, we can read its definition, preserve it somehow and then build an identical tree from it.
In the second part we are building a couple of trees, one identical to the full tree
and another one from just a branch of it</p>

<textarea name="code" class="JScript" cols="60" rows="1">tree2 = new YAHOO.widget.TreeView("treeDiv2", tree1.getTreeDefinition());
tree2.render();

var branch = tree1.getRoot().children[1];
tree3 = new YAHOO.widget.TreeView("treeDiv3", branch.getNodeDefinition());
tree3.render();
</textarea>
<p>For <code>tree2</code> we have used the full tree definition from the first tree.  
For <code>tree3</code> we have first located a branch, for this sample, the second branch from the root
and used its definition for the tree</p>

<p>Finally, in the last tree, we used an object literal to define the full tree.</p>


<textarea name="code" class="JScript" cols="60" rows="1">(new YAHOO.widget.TreeView("treeDiv4",[
	'Label 0',
	{type:'Text', label:'text label 1', title:'this is the tooltip for text label 1'},
	{type:'Text', label:'branch 1', title:'there should be children here', expanded:true, children:[
		'Label 1-0'
	]},
	{type:'Text',label:'YAHOO',title:'this should be an href', href:'http://www.yahoo.com', target:'somewhere new'},
	{type:'HTML',html:'<a href="developer.yahoo.com/yui">YUI</a>'},
	{type:'MenuNode',label:'branch 3',title:'this is a menu node', expanded:false, children:[
		'Label 3-0',
		'Label 3-1'
	]}
])).render();
</textarea>

<p>Here we provide as a second argument to the constructor an array where each item can be either an 
object literal or a simple string, such as <code>'Label 0'</code>, 
which will be converted to a simple TextNode.</p>
<p>The items in the array can also be objects containing more detailed definitions for each node.  
All require a <code>type</code> property using either a short-name such as <code>'Text'</code> or <code>'HTML'</code> (case-insensitive)
or the object name of the node type like <code>'MenuNode'</code>, which will be resolved to YAHOO.widget.MenuNode.</p>
<p>Object definitions allow precise control over the tree since any public property of each node can be specified,
for example, some nodes start expanded while others collapsed. We cannot have such expressiveness from plain HTML markup.</p>
<p>We have defined a couple of external links.  In the first one, labeled <code>YAHOO</code>, the link has the
generic style of the rest of the nodes in the tree.  In the second one, labeled <code>YUI</code>, we have used an HTMLNode
instead of a TextNode so TreeView copies that string into the node without adding further classNames so it gets a different look.</p>
<p>The last node, being a MenuNode, forces other branches to collapse when expanded.  The other node with children, being a plain node
doesn't mind if other nodes remain expanded.</p>
<p>Nodes may contain a <code>children</code> property containing further node definitions.</p>