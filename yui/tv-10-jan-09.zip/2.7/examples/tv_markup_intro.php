<p>In this simple example you can see how to build 
<a href="http://developer.yahoo.com/yui/treeview/">TreeView Control</a> from existing HTML markup 
and from a previous tree definition or from a branch of it.</p>
