<p>This example demonstrates label editing and keyboard navigation in the YUI TreeView Control. 
As you interact with the TreeView instance below, you'll find that some nodes allow you to edit them -
double-click on node labels to open the inline editor. 
This example also demonstrates how you can use arrow keys, +/- keys (expand/collapse), 
and the enter key to navigate and control the TreeView instance.</p>
