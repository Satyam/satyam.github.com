<h2 class="first">Highlighting tree nodes.</h2>

<p>Nodes of the <a href="http://developer.yahoo.com/yui/treeview/">TreeView Control</a> 
can be highlighted in response to a user action or via code.  
That highlighting can affect a single node at a time or multiple nodes and it can propagate up or down the tree.
In this example we show two trees built at random with different node highlighting settings.</p>
<p>We begin by defining the containers that will hold the trees.  
The built-in stylesheet allows for two styles of highlighting, 
the first one, selected via the className <code>ygtv-checkbox</code>, will add a tri-state checkbox
in between the toggle icon and the label, the second, selected via the className <code>ygtv-highlight</code>, 
will change the background of highlighted nodes. 
If neither of those classes are selected, the highlighting will still work, 
but the user won't notice since there will be no visual clues. 
We also add a button to show how highlighted (selected) nodes can be found.</p>

<textarea name="code" class="HTML" cols="60" rows="1"><h3>Tree with highlight propagation and 'checkbox' skin</h3>
<div id="treeDiv1" class="ygtv-checkbox"></div>
<button id="logHilit">Log selected</button>
<hr/>
<h3>Tree with single node highlighting and simple skin</h3>
<div id="treeDiv2" class="ygtv-highlight"></div></textarea>

<p>We create the first TreeView and render it.  
Function <code>makeBranch</code> recursively builds a random branch of TextNodes.
Highlighting is enabled by default, nodes can be highlighted via code, 
but to respond to user events we need to attach the supplied listener <code>onEventToggleHighlight</code> 
to the event we want to respond to.  
We also want the highlighting to propagate both up and down.</p>

<textarea name="code" class="JScript" cols="60" rows="1">tree1 = new YAHOO.widget.TreeView("treeDiv1");
makeBranch(tree1.getRoot());
tree1.subscribe('clickEvent',tree1.onEventToggleHighlight);		
tree1.setNodesProperty('propagateHighlightUp',true);
tree1.setNodesProperty('propagateHighlightDown',true);
tree1.render();
</textarea>

<p>The checkbox is tri-state because when the highlighting propagates up, 
the parent node into which it propagates might not have all its child nodes highlighted,
so the checkbox has a partially checked state.</p>

<p>We can easily find out which nodes have been highlighted by searching the tree by property 
<code>highlighState</code> which will be 0 for not-highlighted, 1 for highlighted 
and 2 for a node that has some children highlighted.</p>

<textarea name="code" class="JScript" cols="60" rows="1">YAHOO.util.Event.on("logHilit","click",function() {
	var hiLit = tree1.getNodesByProperty("highlightState",1);
	var labels = [];
	for (var i = 0; i < hiLit.length; i++) {
		labels.push(hiLit[i].label);
	}
	YAHOO.log("Highlighted nodes:<br/>" + labels.join("<br/>"), "info", "example");
});</textarea>
<p>For <code>tree2</code> we have set property <code>singleNodeHighlight</code> to true 
so that by selecting one node, the currently highlighted node, if any, will be un-highlighted.
The change in appearance is due to the highlighting 'skin' selected.</p>


<textarea name="code" class="JScript" cols="60" rows="1">tree2 = new YAHOO.widget.TreeView("treeDiv2");
makeBranch(tree2.getRoot());
tree2.singleNodeHighlight = true;
tree2.subscribe('clickEvent',tree2.onEventToggleHighlight);		
tree2.render();</textarea>