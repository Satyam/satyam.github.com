<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>TreeView</title> 
		<!-- css --> 
<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.6.0/build/reset/reset-min.css"> 
<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.6.0/build/base/base-min.css"> 
		<link type="text/css" rel="stylesheet" href="../treeview-skin.css">
		<!--link type="text/css" rel="stylesheet" href="http://yui.yahooapis.com/2.6.0/build/treeview/assets/skins/sam/treeview.css"-->
		<link type="text/css" rel="stylesheet" href="http://yui.yahooapis.com/2.6.0/build/logger/assets/skins/sam/logger.css">
		<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.6.0/build/calendar/assets/skins/sam/calendar.css">

 
		<!--script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/yahoo-dom-event/yahoo-dom-event.js" ></script-->
		<script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/yahoo/yahoo.js" ></script>
		<script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/dom/dom.js" ></script>
		<script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/event/event.js" ></script>
		<script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/logger/logger-min.js"></script> 
		<script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/calendar/calendar.js"></script>
		<script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/json/json.js"></script>

		<!--script type="text/javascript" src="http://yui.yahooapis.com/2.6.0/build/treeview/treeview.js"></script-->
		<!-- only one of the following set of files should be uncommented at any one time -->
		
		<!-- uncomment the following lines to try each file separate -->
		<script type="text/javascript" src="../Node.js" ></script>
		<script type="text/javascript" src="../TVAnim.js" ></script>
		<script type="text/javascript" src="../TVFadeIn.js" ></script>
		<script type="text/javascript" src="../TVFadeOut.js" ></script>
		<script type="text/javascript" src="../TextNode.js" ></script>
		<script type="text/javascript" src="../HTMLNode.js" ></script>
		<script type="text/javascript" src="../MenuNode.js" ></script>
		<script type="text/javascript" src="../DateNode.js" ></script>
		<script type="text/javascript" src="../RootNode.js" ></script>
		<script type="text/javascript" src="../TVAnim.js" ></script>
		<script type="text/javascript" src="../TVFadeIn.js" ></script>
		<script type="text/javascript" src="../TVFadeOut.js" ></script>
		<script type="text/javascript" src="../TreeView.js" ></script>
		<script type="text/javascript" src="../TreeViewEd.js" ></script>
		
		</head>
		<body>
<h3>Tree with highlight propagation and 'checkbox' skin</h3>
<div id="treeDiv1"  class="whitebg ygtv-checkbox"></div>
<button id="logHilit">Log selected</button>
<hr/>
<h3>Tree with single node highlighting and simple skin</h3>
<div id="treeDiv2" class="whitebg ygtv-highlight"></div>

<script type="text/javascript">

//global variable to allow console inspection of tree:
var tree1, tree2;

//anonymous function wraps the remainder of the logic:
(function() {
	var makeBranch = function (parent,label) {
		label = label || '';
		var n = Math.random() * (6 - (label.length || 0));
		for (var i = 0;i < n;i++) {
			var tmpNode = new YAHOO.widget.TextNode('label' + label + '-' + i, parent, Math.random() > .5);
			makeBranch(tmpNode,label + '-' + i);
		}
	}


	var treeInit = function() {
		tree1 = new YAHOO.widget.TreeView("treeDiv1");
		makeBranch(tree1.getRoot());
		tree1.setNodesProperty('propagateHighlightUp',true);
		tree1.setNodesProperty('propagateHighlightDown',true);
		tree1.subscribe('clickEvent',tree1.onEventToggleHighlight);		
		tree1.render();

		YAHOO.util.Event.on('logHilit','click',function() {
			var hiLit = tree1.getNodesByProperty('highlightState',1);
			var labels = [];
			for (var i = 0; i < hiLit.length; i++) {
				labels.push(hiLit[i].label);
			}
			YAHOO.log("Highlighted nodes:<br/>" + labels.join("<br/>"), "info", "example");
			console.log(labels.join("\n"));
				
		});


		tree2 = new YAHOO.widget.TreeView("treeDiv2");
		makeBranch(tree2.getRoot());
		tree2.singleNodeHighlight = true;
		tree2.subscribe('clickEvent',tree2.onEventToggleHighlight);		
		tree2.render();
		
		
	};

	//Add an onDOMReady handler to build the tree when the document is ready
    YAHOO.util.Event.onDOMReady(treeInit);

})();

</script>

</body>
</html>