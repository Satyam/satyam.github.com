<p>The TaskNode example implements a task list using treeview.  
It does so by extending the TextNode class to have additional, specific functionality.  
In this example, each TaskNode has three potential states: Checked, partially-checked (not all subtasks complete), and unchecked.  
Checking off a task automatically checks off all subtasks.</p>
<p>Clicking on the checkbox changes its state.  Clicking on the label adds a new sub-task to that task and lets you create the label. 
Double-clicking on a label lets you change the label.  Only newly created tasks can be edited.</p>